<?php include('partials/header.php') ?>

<!-- mainr area start -->
<div class="main-content">
    <div class="wrapper">
        <h4>Manage Category</h4>
 <a class="btn-primary" href="<?php echo SITEURL . 'admin/add-category.php' ?>">Add category</a>
 <?php
 if(isset($_SESSION['cat_success'])){
        echo $_SESSION['cat_success'];
        unset($_SESSION['cat_success']);
 } 
  if(isset($_SESSION['cat_delete_error'])){
        echo $_SESSION['cat_delete_error'];
        unset($_SESSION['cat_delete_error']);
 } 
  if(isset($_SESSION['cat_delete_success'])){
        echo $_SESSION['cat_delete_success'];
        unset($_SESSION['cat_delete_success']);
 } 
 if(isset($_SESSION['cat_Faild_to_remove'])){
    echo $_SESSION['cat_Faild_to_remove'];
    unset($_SESSION['cat_Faild_to_remove']);
} 
if(isset($_SESSION['cat_updated'])){
    echo $_SESSION['cat_updated'];
    unset($_SESSION['cat_updated']);
} 
if(isset($_SESSION['cat_error_update'])){
    echo $_SESSION['cat_error_update'];
    unset($_SESSION['cat_error_update']);
} 
 ?>
            <table class="table-full">
                <tr>
                    <th>
                        S/L
                    </th>
                    <th>
                        Category Name
                    </th>
                    <th>
                        Image
                    </th>
                    <th>
                        Featured
                    </th>
                    <th>
                        Active
                    </th>
                    <th>
                        Action
                    </th>
                </tr>
                <?php

                    //sqli query 
                $sql = "SELECT * FROM noman_test";

                // Execute the query
                $res = mysqli_query($conn, $sql) or die(mysqli_error());

                // count the row ( is there any data available or not)
                $count = mysqli_num_rows($res);

                if($count == true ){
                    // execute the html with data
                    $sl = 1;
                    while ($rows = mysqli_fetch_assoc($res)) { 
                    
                    ?>
                    <tr>
                    <td>
                        <?php echo $sl++; ?>.
                    </td>
                    <td>
                        <?php echo $rows['cat_name']; ?>
                    </td>
                    <td>
                        <?php 

                        if($rows['cat_image']){ ?>
                        <img class="cat-img-cover" src="<?php echo SITEURL ?>media-file/category/<?php echo $rows['cat_image']; ?>" alt="">
                    <?php }
                    else {
                        echo "<div class='error'>No Image added...</div>";
                    }
                     ?>
                    </td>
                    <td>
                        <?php echo $rows['cat_featured']; ?> 
                    </td>
                    <td>
                        <?php echo $rows['cat_active']; ?>
                    </td>
                    <td>
                        <a class="btn-secondary" href="update-category.php?id=<?= $rows['id'] ?>">Update Category</a>
                        <a class="btn-danger" href="delete-category.php?id=<?php echo $rows['id'];?><?php if($rows['cat_image']){ echo "&imageName=" . $rows['cat_image'];} ?>">Delete Category</a>
                        
                    </td>
                </tr>
                    <?php
                }}
                else
                {
                    echo "Sorry We Don't have any data!";
                }
                 ?>


            </table>

    </div>
    <div class="clearfix"></div>
</div>
<!-- main area end -->


<?php include('partials/footer.php'); ?>