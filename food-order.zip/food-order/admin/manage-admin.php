
<?php include('partials/header.php') ?>
<!-- mainr area start -->
<div class="main-content">
    <div class="wrapper">
        <h4>Manage Admin</h4>
            <a class="btn-primary" href="add-admin.php">Add Admin</a>
            <?php
                if(isset($_SESSION['add'])){
                    echo $_SESSION['add']; // displaying the message
                    unset($_SESSION['add']); // removing session message
                }
                if(isset($_SESSION['delete-admin'])){
                    echo $_SESSION['delete-admin'];
                    unset($_SESSION['delete-admin']);
                    
                }
                if(isset($_SESSION['update'])){
                    echo $_SESSION['update'];
                    unset($_SESSION['update']);
                    
                }
                if(isset($_SESSION['pass-change-success'])){
                    echo $_SESSION['pass-change-success'];
                    unset($_SESSION['pass-change-success']);
                    
                }
                 if(isset($_SESSION['login-success'])){
                    echo $_SESSION['login-success'];
                    unset($_SESSION['login-success']);
                    
                }

            ?>
            <table class="table-full">
                <tr>
                    <th>
                        S/L
                    </th>
                    <th>
                        Full Name
                    </th>
                    <th>
                        Username
                    </th>
                    <th>
                        Action
                    </th>
                </tr>

                <?php 
                    $sql = "SELECT * FROM tbl_admin";
                    $res = mysqli_query($conn,$sql);
                    $count = mysqli_num_rows($res); // get all the row in the table
                    
                    $sn = 1; // variable init for the serial number

                    //check the rows condition
                    if($count > 0)
                        {
                            // $rows = mysqli_fetch_assoc($res);
                            // print_r($rows['full_name']); 
                            while ($rows = mysqli_fetch_assoc($res)) {
                             //   print_r($rows['full_name']); ?>
                             <tr>
                    <td>
                        <?php echo $sn++ ?>
                    </td>
                    <td>
                        <?php echo $rows['full_name']; ?>
                    </td>
                    <td>
                        <?php echo $rows['username']; ?>
                    </td>
                    <td>
                        <a class="btn-blue" href="<?php echo SITEURL;?>admin/change-pass.php?id=<?php echo $rows['Id']; ?>">Change Password</a>
                        <a class="btn-secondary" href="<?php echo SITEURL;?>admin/update-admin.php?id=<?php echo $rows['Id']; ?>">Update Admin</a>
                        <a class="btn-danger" href="<?php echo SITEURL;?>admin/delete-admin.php?id=<?php echo $rows['Id'];?>">Delete Admin</a>
                        
                    </td>
                </tr>

<?php
                            }
                        }

                ?>


            </table>
    </div>
    <div class="clearfix"></div>
</div>
<!-- main area end -->


<?php include('partials/footer.php') ?>

