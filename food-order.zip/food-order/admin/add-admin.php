<?php include('partials/header.php'); ?>
<!-- mainr area start -->
<div class="main-content">
    <div class="wrapper">
    	add your admin

    	<form action="" method="POST">
    		<table class="table-30">
    			<tr>
    				<td>Full Name: </td>
    				<td><input type="text" name="full_name" placeholder="Enter your name here"></td>
    			</tr>
    			<tr>
    				<td>Username: </td>
    				<td><input type="text" name="username" placeholder="Enter your Username here"></td>
    			</tr>
    			<tr>
    				<td>Password: </td>
    				<td><input type="Password" name="password" placeholder="Enter your Password here"></td>
    			</tr>
    			<tr>
    				<td colspan="2">
    					<input type="submit" class="btn-secondary" name="submit">
    				</td>
    			</tr>
    		</table>
    		<?php
    			if(isset($_SESSION['add'])){
    				echo $_SESSION['add'];
    				unset($_SESSION['add']);
    			}
    		?>
    	</form>
   </div>
</div>
<?php include('partials/footer.php') ?>

<?php
	
	if(isset($_POST['submit'])){


		// get value
		$full_name = $_POST['full_name'];
		$username = $_POST['username'];
		$password = md5($_POST['password']); //password encrption
		//echo $full_name, $username, $password;

		// sql query to save into database

		$sql = "INSERT INTO tbl_admin SET
			full_name = '$full_name',
			username = '$username',
			password = '$password'
		";



		// executing the query to database
		$res = mysqli_query($conn, $sql) or die(mysqli_error());

		if($res = true){
			$_SESSION['add'] = 'Admin Added successfully!!';

			// redirect to manage admin page
			header('Location:'.SITEURL.'admin/manage-admin.php');
		}
		else{
			$_SESSION['add'] = 'Fail to add new admin -_-';

			// redirect to manage admin page
			header('Location:'.SITEURL.'admin/add-admin.php');
		}
	}

?>








