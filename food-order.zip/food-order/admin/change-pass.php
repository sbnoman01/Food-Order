<?php include('partials/header.php'); ?>


<!-- mainr area start -->
<div class="main-content">
    <div class="wrapper">
        <h4>Change Your Password</h4>

<?php
		if(isset($_GET['id'])){
			$id = $_GET['id'];
			echo $id;
		}
 ?>

        <form class="table-30" method="POST" action=""> 


        	<tr>
        		<td>
        			Current Password:
        		</td>
        		<td>
        			<input type="Password" name="old_pass">
        		</td>

        	</tr>
        	<tr>
        		<td>
        			New Password:
        		</td>
        		<td>
        			<input type="Password" name="new_password">
        		</td>
        	</tr>
        	<tr>
        		<td>
        			Confirm Password:
        		</td>
        		<td>
        			<input type="Password" name="confrim_password">
        			<input type="hidden" value="<?php $id ?>" name="id">
        		</td>
        		<input type="submit" name="submit">
        	</tr>


        </form>
    </div>
</div>

<?php

if (isset($_POST['submit'])) {
	// catch the form data
	$current_id = $_POST['id'];
	$current_pass = md5($_POST['old_pass']);
	$new_pass = md5($_POST['new_password']);
	$confirm_pass = md5($_POST['confrim_password']);

	$sql = "SELECT * FROM tbl_admin WHERE Id = $id AND password = '$current_pass'";
	$res = mysqli_query($conn, $sql);

	if($res == true){
		
		$count = mysqli_num_rows($res);
		if ($count == true) {
			$rows = mysqli_fetch_assoc($res);
			if( $new_pass == $current_pass ){
				echo "please choose a new password!";
			}
			elseif($new_pass == $confirm_pass){

				$sql = "UPDATE tbl_admin SET password='$confirm_pass' WHERE Id = $id";
				$res = mysqli_query($conn, $sql);


				if($res == true){
				$_SESSION['pass-change-success'] = 'Password Changed Successfully!!';
				header('Location:' . SITEURL . 'admin/manage-admin.php');
				}

			else
				echo 'sorry';
			}
			else
			{
				echo "pass did not match or ";
			}
		}
		else
		{
			echo "Current Password is wrong!";
		}
	}
	else
	{
		echo 'pass wrong';
		echo $id;
		
	}
}

?>

<?php include('partials/footer.php'); ?>