<?php 

include('../config/constants.php');


// get the id
$id = $_GET['id'];


$sql = "DELETE FROM tbl_admin WHERE Id=$id";
$res = mysqli_query($conn, $sql);

if($res == true){
	$_SESSION['delete-admin'] = 'You have successfully delete the admin!!';
	header('Location:' .SITEURL . 'admin/manage-admin.php');
}
else{
	$_SESSION['delete-admin'] = 'We are unable to delete the admin!!';
	header('Location:' .SITEURL . 'admin/manage-admin.php');

}


?>