<?php include('partials/header.php') ?>

<!-- mainr area start -->
<div class="main-content">
    <div class="wrapper">
        <h4>Manage Order</h4>

            <table class="table-full">
                <tr>
                    <th>
                        S/L
                    </th>
                    <th>
                        Customer Name
                    </th>
                    <th>
                        Contact
                    </th>
                    <th>
                        Email
                    </th>
                    <th>
                        address
                    </th>
                    <th>
                        Food Name
                    </th>
                    <th>
                        QTY
                    </th>
                    <th>
                        Total Price
                    </th>
                    <th>
                        Date
                    </th>
                    <th>
                        Status
                    </th>
                    <th>
                        Action
                    </th>
                </tr>
                <?php
                    // sql for get order lint
                    $sql_orderd_list = "SELECT * FROM tbl_order ORDER BY id DESC";
                    $query_sql_orderd_list = mysqli_query($conn, $sql_orderd_list);
                    $count_row = mysqli_num_rows($query_sql_orderd_list);
                    if($count_row > 0){
                        $sl = 1;
                        while($order = mysqli_fetch_assoc($query_sql_orderd_list)){
                            extract($order);
                            
                            ?>
                <tr>
                    <td>
                        <?= $sl++; ?>
                    </td>
                    <td>
                        <?= $customer_name ?>
                    </td>
                    <td>
                    <?= $customer_contact; ?>
                    </td>
                    <td>
                    <?= $customer_email; ?>
                    </td>
                    <td>
                    <?= $customer_address; ?>
                    </td>
                    <td>
                    <?= $food; ?>
                    </td>
                    <td>
                    <?= $qty; ?>
                    </td>
                    <td>
                    <?= $total; ?>
                    </td>
                    <td>
                    <?= $order_date; ?>
                    </td>
                    <td>
                    <?= $status; ?>
                    </td>
                    <td>
                        <a class="btn-secondary" href="#">Update</a>
                    </td>
                </tr>
                            <?php
                        }
                    }

                ?>

            </table>
    </div>
    <div class="clearfix"></div>
</div>
<!-- main area end -->


<?php include('partials/footer.php') ?>