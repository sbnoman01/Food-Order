<?php include('partials/header.php') ?>
<?php

// session messsage
if(isset($_SESSION['food-image-faild'])){
    echo $_SESSION['food-image-faild'];
    unset($_SESSION['food-image-faild']);
} 
if(isset($_SESSION['success_add_food'])){
    echo $_SESSION['success_add_food'];
    unset($_SESSION['success_add_food']);
} 
if(isset($_SESSION['food_del_succ'])){
    echo $_SESSION['food_del_succ'];
    unset($_SESSION['food_del_succ']);
} 
if(isset($_SESSION['food_del_error'])){
    echo $_SESSION['food_del_error'];
    unset($_SESSION['food_del_error']);
} 
if(isset($_SESSION['food_img_error'])){
    echo $_SESSION['food_img_error'];
    unset($_SESSION['food_img_error']);
} 

if(isset($_SESSION['food_upate_error'])){
    echo $_SESSION['food_upate_error'];
    unset($_SESSION['food_upate_error']);
} 
if(isset($_SESSION['food_upate_success'])){
    echo $_SESSION['food_upate_success'];
    unset($_SESSION['food_upate_success']);
} 
if(isset($_SESSION['image_update_error'])){
    echo $_SESSION['image_update_error'];
    unset($_SESSION['image_update_error']);
}
if(isset($_SESSION['image_name_update_error'])){
    echo $_SESSION['image_name_update_error'];
    unset($_SESSION['image_name_update_error']);
} 
if(isset($_SESSION['old_mage_remove_error'])){
    echo $_SESSION['old_mage_remove_error'];
    unset($_SESSION['old_mage_remove_error']);
} 
?>
<!-- mainr area start -->
<div class="main-content">
    <div class="wrapper">
        <h4>Manage Food</h4>
<a class="btn-primary" href="add-food.php">Add Food</a>
    <table class="table-full">
        <tr>
            <th>
                S/L
            </th>
            <th>
                Food Name
            </th>
            <th>
                Image
            </th>
            <th>
                Category
            </th>
            <th>
                Featured
            </th>
            <th>
                Status
            </th>
            <th>
                Price
            </th>
            <th>
                Action
            </th>
        </tr>
        <?php
        // sql for food information
            $sql_food_collect = "SELECT * FROM tbl_food";
            $query_food_collect = mysqli_query($conn, $sql_food_collect);
        // sql for category info
            $count_food = mysqli_num_rows($query_food_collect);
            $sn = 1;
            if($count_food > 0){
                while($food = mysqli_fetch_assoc($query_food_collect)){ ?>
        <tr>
            <td>
                <?= $sn++ ?>
            </td>
            <td>
                <?= $food['f_name']; ?>
            </td>
            <td>
                <img width="150px" src="../media-file/food/<?= $food['f_image_name']; ?>" alt="">
            
            </td>
            <td>
            <?= $food['category_id']; ?>
            </td>
            <td>
            <?= $food['f_featured']; ?>
            </td>
            <td>
            <?= $food['f_active']; ?>
            </td>
            <td>
            $<?= $food['f_price']; ?>
            </td>
            <td>
                <a class="btn-primary" href="update-food.php?id=<?= $food['f_id']?>&image=<?= $food['f_image_name'];?>">Update Food</a>
                <a class="btn-danger" href="delete-food.php?id=<?= $food['f_id']?>&image=<?= $food['f_image_name'];?>">Delete Food</a>
                
            </td>
        </tr>

        <?php }
            }
            else{
                echo "Sorry No food added yet!";
            } ?>

        </table>
    </div>
    <div class="clearfix"></div>
</div>
<!-- main area end -->


<?php include('partials/footer.php') ?>