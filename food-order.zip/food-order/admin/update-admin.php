<?php include('partials/header.php') ?>
<!-- mainr area start -->
<div class="main-content">
    <div class="wrapper">
        <h4>Update Admin</h4>


        	<?php
        		// get the url id
        	$id = $_GET['id']; 


        	// execute the query
        		$sql = "SELECT * FROM tbl_admin WHERE Id=$id";
        		$res = mysqli_query($conn, $sql);

        		if($res == true){
        			//echo "string";
        			$count = mysqli_num_rows($res);
        			if($count == 1){
        					//code
        				$row = mysqli_fetch_assoc($res);
        				$get_full_name = $row['full_name'];
        				$get_username = $row['username']; echo $get_full_name;

        			}
        			else{
        				header("Location:" . SITEURL . "admin/manage-admin.php");
        			}
        		}
        		else
        		{
        			header("Location:" . SITEURL . "admin/manage-admin.php");
        		}
        	 ?>
	<form action="" method="POST">
    		<table class="table-30">
    			<tr>
    				<td>Full Name: </td>
    				<td><input type="text" name="full_name" value="<?php echo $get_full_name; ?>" placeholder="Enter your name here"></td>
    			</tr>
    			<tr>
    				<td>Username: </td>
    				<td><input type="text" name="username" value="<?php echo $get_username; ?>" placeholder="Enter your Username here"></td>
    			</tr>
    			
    			<tr>
    				<td colspan="2">
    					<input type="submit" class="btn-secondary" name="submit" value="Update">
    				</td>
    			</tr>
    		</table>
    		<?php
    			if(isset($_SESSION['update'])){
    				echo $_SESSION['update'];
    				unset($_SESSION['update']);
    			}


    			//get the update data
    			if(isset($_POST['submit'])){
    				//catch udpate data
    				$up_full_name = $_POST['full_name'];
    				$up_username = $_POST['username'];
    				echo $up_username, $up_full_name, $id;
    				$sql = "UPDATE tbl_admin SET 
    					full_name = '$up_full_name',
    					username = '$up_username',
    					password = '$up_password'
    					WHERE Id = '$id'
    				";
    				//UPDATE `tbl_admin` SET `full_name` = 'abdullahsss' WHERE `tbl_admin`.`Id` = 7;
    				$res = mysqli_query($conn, $sql) or die(mysqli_error());

    				if($res == true){
    					$_SESSION['update'] = 'You have successfully Updated the admin';
    					header('Location:' .SITEURL. 'admin/manage-admin.php');
    				}
    				else{
    					 $_SESSION['update'] = 'Sorry update faild!!';
    					header('Location:' .SITEURL. 'admin/update-admin.php');
    				}

    			}
    		?>
    	</form>
    </div>
</div>
<?php include('partials/footer.php');