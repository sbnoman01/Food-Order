<?php include('../config/constants.php');

if(!isset($_SESSION['username'])){
    header('Location:' .SITEURL. 'admin/login.php');
}

 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Welcome To admin</title>
    <link rel="stylesheet" type="text/css" href="../css/admin.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>

<!-- header area start -->
<div class="header">
    <div class="wrapper">
        <div class="menu text-center">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="manage-admin.php">admin</a></li>
                <li><a href="manage-category.php">Category</a></li>
                <li><a href="manage-food.php">food</a></li>
                <li><a href="manage-order.php">order</a></li>
                <li><a href="<?= SITEURL ?>index.php">FronEnd</a></li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
        </div>
    </div>
</div>
<!-- header area end -->
