<?php
include('../config/constants.php');
// destroy the session
	session_destroy();
// redrect to home page
	header('Location:'.SITEURL.'admin/login.php');

?>