<!-- footer area start -->
<div class="footer">
    <div class="wrapper">
        <p class="text-center text-white">
            this website is developed by noman
        </p>
    </div>
</div>
<!-- footer area end -->


</body>
</html>