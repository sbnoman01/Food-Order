
<?php
include('../config/constants.php');

if(isset($_GET['id']) && isset($_GET['image'])){
    $id =  $_GET['id'];
    $image_name = $_GET['image'];
    

    // check if the id is availbale on db
    $sql_check_value = "SELECT * FROM tbl_food WHERE f_id='$id' AND f_image_name='$image_name'";
    $query_sql_check_value = mysqli_query($conn, $sql_check_value);
    $count_rows = mysqli_num_rows($query_sql_check_value);
    if($count_rows == 1){
        // delte the image from media file
        $img_path = "../media-file/food/". $image_name;
        $remove_img = unlink($img_path);
        if($remove_img == true){
            $sql_del_value = "DELETE FROM tbl_food WHERE f_id='$id'";
            $query_sql_del_value = mysqli_query($conn, $sql_del_value);
            if($query_sql_del_value){
                // set the session message
                $_SESSION['food_del_succ'] = "Successfully deleted the food..";
                linkto('admin/manage-food.php');
            }
            else{
                $_SESSION['food_del_error'] = "Error to deleted the food..";
            }
        }
        else{
            $_SESSION['food_img_error'] = "Error to deleted the image..";
        }


    }
    else{
        linkto('admin/manage-food.php');
    }
}
else{
    linkto('admin/manage-food.php');
}
?>