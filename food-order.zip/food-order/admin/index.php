
<?php include('partials/header.php') ?>
<!-- mainr area start -->
<div class="main-content">
    <div class="wrapper">
        <h4>DASHBOARD</h4>
<?php
 if(isset($_SESSION['login-success'])){
                    echo $_SESSION['login-success'];
                    unset($_SESSION['login-success']);
                    
                }

        // sql query to desplay the category
        // $sql_get_cat = "SELECT * FROM `tbl_category`";
        // $query_sql_get_cat = mysqli_query($conn, $sql_get_cat);
        // $total_cat = mysqli_num_rows($query_sql_get_cat);
        // echo mysqli_error($query_sql_get_cat);          

?>
        <div class="col-4 bg-white text-center">
            <h1>10</h1>
            <p>Total Cetagory</p>
        </div>

        <div class="col-4 bg-white text-center">
            <h1>5</h1>
            <p>Category</p>
        </div>

        <div class="col-4 bg-white text-center">
            <h1>5</h1>
            <p>Category</p>
        </div>

        <div class="col-4 bg-white text-center">
            <h1>5</h1>
            <p>Category</p>
        </div>
    </div>
    <div class="clearfix"></div>
</div>
<!-- main area end -->


<?php include('partials/footer.php') ?>

