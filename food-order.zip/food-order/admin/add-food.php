<?php include('partials/header.php') ?>
<!-- mainr area start -->
<div class="main-content">
    <div class="wrapper">
        <h1 class="text-center">Add New Food</h1>

            <div class="add-food row justify-content-center">
                <form action="" method="POST" class="bg-white p-4" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="foodName">Food Name</label>
                        <input type="text" class="form-control" id="foodName" placeholder="Food Name" name="food-name">
                    </div>

                    <div class="form-group">
                        <label for="foodPrice">Food Price</label>
                        <input type="number" class="form-control" id="foodPrice" placeholder="Price"  name="food-price">
                    </div>

                    <div class="form-group">
                        <label for="foodCategory">Caetegory select</label>
                        <select class="form-control" id="foodCategory" name="food-category">
                        <?php 
                            // sql query to gether category name
                            $sql_food_cat = "SELECT * FROM noman_test WHERE cat_active='Yes'";
                            $query_sql_food_cat = mysqli_query($conn, $sql_food_cat);
                            $count_rows = mysqli_num_rows($query_sql_food_cat);

                            if($count_rows > 0){
                                while($data = mysqli_fetch_assoc($query_sql_food_cat)){
                                    echo '<option value="'. $data['id'] .'" >' . $data['cat_name'] . '</option>';
                                }
                            }
                            else{
                                // show the deafult data if no category found
                                echo '<option value="0" > - No catagory Found -</option>';
                            }
                            
                        ?>
                        </select>
                        
                    </div>

                    <div class="form-check form-check-inline">
                        <p class="d-block">Featured</p><br>
                        <input class="form-check-input" type="radio" name="featured_food" id="foodFeaturedYes" value="Yes">
                        <label class="form-check-label" for="foodFeaturedYes">Yes</label>

                        <input class="form-check-input" type="radio" name="featured_food" id="foodFeaturedNo" value="No">
                        <label class="form-check-label" for="foodFeaturedNo">No</label>
                    </div>
                    <br>
                    <div class="form-check form-check-inline">
                        <p class="d-block">Active statuse</p><br>
                        <input class="form-check-input" type="radio" name="active_food" id="foodactiveYes" value="Yes">
                        <label class="form-check-label" for="foodactiveYes">Yes</label>
    
                        <input class="form-check-input" type="radio" name="active_food" id="foodactiveNo" value="No">
                        <label class="form-check-label" for="foodactiveNo">No</label>
                    </div>
                    
                    <div class="form-group">
                        <label for="foodImage">Food Image</label>
                        <input type="file" class="form-control-file" id="foodImage"  name="food-image">
                    </div>
                    <div class="form-group">
                        <label for="foodDesc">Food Description</label>
                        <textarea class="form-control" id="foodDesc" rows="3"  name="food-description"></textarea>
                    </div>

                    <button type="add-food" name="add-food" class="btn btn-primary">Submit</button>

                </form>
                
            </div>
    </div>
    <div class="clearfix"></div>
</div>
<!-- main area end -->
<?php

if(isset($_POST['add-food'])){

    // 1. agether all filed data
    $f_name = $_POST['food-name'];
    $f_price = $_POST['food-price'];
    $f_category = $_POST['food-category'];
            // set deafult data for featured
        if(isset($_POST['featured_food'])){
            $f_featured = $_POST['featured_food'];
        }
        else{
            $f_featured = 'No';
        }    
            // set deafult data for active status
        if(isset($_POST['active_food'])){
            $f_status = $_POST['active_food'];
        }
        else{
            $f_status = 'No';
        }

    $f_description = $_POST['food-description'];

    // 2. upload image

    if(isset($_FILES['food-image']) && isset($_FILES['food-image']['name'])){
        // image name
        $f_image_name = $_FILES['food-image']['name'];

        // image path
        $f_image_path = "../media-file/food/" . $f_image_name;
        
        if( $f_image_name != ''){
            // get the extention
            $explode_img = explode('.', $f_image_name);
            $extention_img = end($explode_img);

            // rename the image
            $new_img_name = "food-name-" . rand(0000,9999) . "." .$extention_img;

            // image temp
            $f_image_temp = $_FILES['food-image']['tmp_name'];
            // image path
            $f_image_path = "../media-file/food/" . $new_img_name;

            // move the file to host
           $upload = move_uploaded_file($f_image_temp, $f_image_path);

           // check if the upload successfull
           if($upload == false){
               $_SESSION['food-image-faild'] = "WE faild to upload the image";
               linkto('admin/manage-food.php');
               die();
           }
          
        }
    }
    else{
        $f_image_name = '';
    }

    // 3. insurt the value database

    $sql_add_food = "INSERT INTO tbl_food SET
        f_name = '$f_name',
        f_description = '$f_description',
        f_price = '$f_price',
        f_image_name = '$new_img_name',
        category_id = '$f_category',
        f_featured = '$f_featured',
        f_active = '$f_status'
    ";
    $query_sql_add_food = mysqli_query($conn, $sql_add_food);
    // 4. redirect to manage food
    if($query_sql_add_food == true){
        $_SESSION['success_add_food'] = 'New food added successfully!';
        echo '<script>window.location.href = " ' . SITEURL . '/admin/manage-food.php' . ' ";</script>';
    }
    else{
        echo "insert error";
    }
    //f_name, f_description, f_price, f_image_name, category_id, f_featured, f_active
}

?>
<?php include('partials/footer.php') ?>