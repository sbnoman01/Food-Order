<?php include('partials/header.php'); ?>

<!-- add-category.php -->


<!-- mainr area start -->
<div class="main-content">
    <div class="wrapper">
    	<h4>Add Category</h4>
    	<?php 
    		if(isset($_SESSION['cat_img'])){
    			echo $_SESSION['cat_img'];
    			unset($_SESSION['cat_img']);
    		}
    	?>


    	<form action="" method="POST" enctype="multipart/form-data">
    		<label for="cat_title">Category Title</label>
    		<input type="text" name="category_title" id ="cat_title" placeholder="Category Name">
    	</br>
    		<label for="cat_img">Upload Caegory Image</label><br>
    		<input type="file" name="cat_img" id="cat_img">
    	<br><br>
    		<label for="featured_cat">Set Featured</label><br>
    		<input type="radio" name="featured_cat" value="Yes">Yes
    		<input type="radio" name="featured_cat" value="No">No

    	<br><br>
    		<label for="Active_cat">Set Active</label><br>
    		<input type="radio" name="active_cat" value="Yes">Yes
    		<input type="radio" name="active_cat" value="No">No
    	<br><br>
    		<input type="submit" name="submit" class="btn-secondary">
    	</form>


    </div>
</div>

<?php include('partials/footer.php'); 

if(isset($_POST['submit'])){
	
 $cat_name = $_POST['category_title'];

// get featured value
 if(isset($_POST['featured_cat'])){
 	$featured = $_POST['featured_cat'];
 }
 else{
 	$featured = 'No';
 }

 // get active statuse 
 if(isset($_POST['active_cat'])){
 	$active = $_POST['active_cat'];
 }
 else{
 	$active = 'No';
 }

 // get image
 if(isset($_FILES['cat_img']['name'])){
 	

 	// image name
 	$cat_image = $_FILES['cat_img']['name'];

 	// path link
 	$cat_img_path = $_FILES['cat_img']['tmp_name'];

 	// destination 
 	$destination_path = "../media-file/category/" . $cat_image;

 	// upload
 	$upload = move_uploaded_file($cat_img_path, $destination_path);

 	if($upload = false || empty($upload)){
 		// set message
 		$_SESSION['cat_img'] = "<div class='error'>Faild to upload image</div>";
 		// start
 		header("location:" .SITEURL. '/admin/add-category.php');
 		die();

 	}
 }

// sql
//print_r($_FILES['cat_img']); die();

$sql = "INSERT INTO noman_test SET
			cat_name= '$cat_name',
			cat_image= '$cat_image',
			cat_featured= '$featured',
			cat_active= '$active'
		";




		// executing the query to database
		$res = mysqli_query($conn, $sql) or die(mysqli_error());
 if($res == true){
 	
 	// set the message and redirect
 	$_SESSION['cat_success'] = "<div class='success d-block'>category Added successfully</div>";
 	header("Location:" .SITEURL. '/admin/manage-category.php');
 }
 else{
 	echo "ss";
 }



}





?>