<?php include('partials/header.php'); ?>

<!-- add-category.php -->

<?php

// $sql = "SELECT * FROM noman_test WHERE id=$id";

if(isset($_GET['id'])){
	$id = $_GET['id'];
	$sql = "SELECT * FROM noman_test WHERE id=$id";
	$res = mysqli_query($conn, $sql);
	$row = mysqli_num_rows($res);

	// check if the passed valu is available on database
	if($row == 1){
		// the id is varified

		$data = mysqli_fetch_assoc($res);
		$name = $data['cat_name'];
		$featured = $data['cat_featured'];
		$active = $data['cat_active'];
		$current_img = $data['cat_image'];
		
	}
	else{
		// data is not vaild 
		linkto('admin/manage-category.php');
	}
}
else{
	linkto('admin/manage-category.php');
}

?>
<!-- mainr area start -->
<div class="main-content">
    <div class="wrapper">
    	<h4>Add Category</h4>



    	<form action="" method="POST" enctype="multipart/form-data">
    		<label for="cat_title">Category Title</label>
    		<input type="text" name="cat-name" id ="cat_title" placeholder="Category Name" value="<?= $name ?>">
    	</br>
		<label calss="cat_img">Current image</label>
		<img width="150px" src="<?= SITEURL . 'media-file/category/' . $current_img?>">
    	</br>

    		<label for="cat_img">Upload Caegory Image</label><br>
    		<input type="file" name="new-cat-image" id="cat_img">
    	<br><br>
    		<label for="featured_cat">Set Featured</label><br>
    		<input <?php if($featured == 'Yes'){ echo 'checked'; } ?> type="radio" name="featured_cat" value="Yes">Yes
    		<input <?php if($featured == 'No'){ echo 'checked'; } ?> type="radio" name="featured_cat" value="No">No

    	<br><br>
    		<label for="Active_cat">Set Active</label><br>
    		<input <?php if($active == 'Yes'){ echo 'checked'; } ?> type="radio" name="active_cat" value="Yes">Yes
    		<input <?php if($active == 'No'){ echo 'checked'; } ?> type="radio" name="active_cat" value="No">No
    	<br><br>
    		<input type="submit" value="Update Category" name="update-category" class="btn-secondary">
    	</form>

    </div>
</div>

<?php
//validate the updated data
if(isset($_POST['update-category'])){
	// get all the updated value

	$name = $_POST['cat-name'];
	//$img = $_FILES['new-cat-image'];
	$featured = $_POST['featured_cat'];
	$active = $_POST['active_cat'];

	// uploading image

	if(isset($_FILES['new-cat-image']['name']) && isset($_FILES['new-cat-image']['name']) != '' ){

		// image name
		$img_new = $_FILES['new-cat-image']['name'];
		
		// image tmp name
		$new_image_path = $_FILES['new-cat-image']['tmp_name'];

		// host destination
		$destination_new_image = "../media-file/category/" . $img_new ;

		// upload the file to host
		$upload = move_uploaded_file($new_image_path, $destination_new_image);

		if($upload == true){
			echo "image uploaded successfully";
			//get the current image  path
			$current_path = '../media-file/category/'.$current_img;
			$remove_current_img = unlink($current_path);

			if($remove_current_img == true){

				// update the new image name to database
				$update_img_sql = "UPDATE noman_test SET cat_image= '$img_new' WHERE id=$id";
				$update_img_res = mysqli_query($conn, $update_img_sql);
				if($update_img_res == false){
					$_SESSION['update_image_db_faild'] = 'Faild to update image name to database';
				}

			}
			else{
				echo "faild to remove";
			}
		}
	}






	// updating field
	$update_sql = "UPDATE noman_test SET
		cat_name = '$name',
		cat_featured = '$featured',
		cat_active = '$active' 	WHERE id=$id";
	$update_query = mysqli_query($conn, $update_sql);
	if($update_query == true){
		
		// if value update sucessfully
		$_SESSION['cat_updated'] = 'Category Updted Successfully';

		// redirect to manage category
		linkto('admin/manage-category.php');
	}
	// redirect with success message
	else{
		// if value update sucessfully
		$_SESSION['cat_error_update'] = 'Category Updted error';

		// redirect to manage category
		linkto('admin/manage-category.php');
	}

}

?>

<?php include('partials/footer.php'); 