<?php include('../config/constants.php') ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login Page</title>
	<link rel="stylesheet" type="text/css" href="../css/admin.css">
</head>
<body>
<div class="main-content login-page">
    <div class="wrapper">
        <h1>Please Login</h1><br>
        	<form class="text-center" action="" method="POST">
        		<label>User Name:</label>
        		<input type="text" name="username">

        		<label>Password:</label>
        		<input type="Password" name="password">
        		<input class="btn-primary" type="submit" name="submit">
        		<?php if(isset($_SESSION['login-faild'])){
        			echo $_SESSION['login-faild'];
        			unset($_SESSION['login-faild']);
        		} ?>
        	</form>
    </div>
</div>
</body>
</html>

<?php include('partials/footer.php'); ?>
<?php 

if(isset($_POST['submit'])){

	// catch the value

		$username = $_POST['username'];
		$password = md5($_POST['password']);

	// connect database
		// $sql = "SELECT * FROM tbl_admin WHERE Id=$id";
		$sql = "SELECT * FROM tbl_admin WHERE username = '$username' AND password = '$password'";
		$res = mysqli_query($conn, $sql);
		// return how many rows available with the same credintials it should be one to continue
		$count = mysqli_num_rows($res);
		if ($res == true AND $count == 1) {			
			
			$_SESSION['login-success'] = 'Login Success';
			$_SESSION['username'] = $username;
			header('Location:' .SITEURL. '/admin');

		}
		else
		{
			$_SESSION['login-faild'] = 'Username And password did not matched';
			header('Location:' .SITEURL. '/admin/login.php');
		}
	// compear the login
}

?>