<?php include('partials/header.php') ?>
<?php

// validate the passed data
if(isset($_GET['id']) && isset($_GET['image'])){
    $id =  $_GET['id'];
    $image_name = $_GET['image'];
    
    // check if the id is availbale on db
    $sql_check_value = "SELECT * FROM tbl_food WHERE f_id='$id' AND f_image_name='$image_name'";
    $query_sql_check_value = mysqli_query($conn, $sql_check_value);
    $count_rows = mysqli_num_rows($query_sql_check_value);
    if($count_rows == 1){
        // gether all the data from database
        $food_inf = mysqli_fetch_assoc($query_sql_check_value);

        // store the valu
        $f_name_old = $food_inf['f_name'];
        $f_price_old = $food_inf['f_price'];
        $f_desc_old = $food_inf['f_description'];
        $f_img_name_old = $food_inf['f_image_name'];
        $f_cat_old = $food_inf['category_id'];
        $f_fatured_old = $food_inf['f_featured'];
        $f_active_old = $food_inf['f_active'];
    }
    else{
        linkto('admin/manage-food.php');
    }
}
?>

<!-- mainr area start -->
<div class="main-content">
    <div class="wrapper">
        <h1 class="text-center">Update your Food</h1>

            <div class="add-food row justify-content-center">
                <form action="" method="POST" class="bg-white p-4" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="foodName">Food Name</label>
                        <input type="text" class="form-control" id="foodName" placeholder="Food Name" name="food-name-update" value="<?= $f_name_old; ?>">
                    </div>

                    <div class="form-group">
                        <label for="foodPrice">Food Price</label>
                        <input type="number" class="form-control" id="foodPrice" placeholder="Price"  name="food-price-update" value='<?= $f_price_old; ?>'>
                    </div>

                    <div class="form-group">
                        <label for="foodCategory">Caetegory select</label>
                        <select class="form-control" id="foodCategory" name="food-category-update">
                            <?php
                            $sql_get_f_cat = "SELECT * FROM noman_test WHERE cat_active='Yes'";
                            $query_sql_get_f_cat = mysqli_query($conn, $sql_get_f_cat);
                            $count_cat_rows = mysqli_num_rows($query_sql_get_f_cat);
                            
                            // cehck the cat 
                            if($count_cat_rows > 0){
                                // category found
                                while($cat_inf = mysqli_fetch_assoc($query_sql_get_f_cat)){
                                ?>
                                    <option value="<?= $cat_inf['id'] ?>"><?= $cat_inf['cat_name'] ?></option>
                                <?php
                            }
                        }
                            else{
                                // no can found
                                echo '<option value="No category">NO cat</option>';
                            }
                            ?>
                            
                        </select>
                        
                    </div>

                    <div class="form-check form-check-inline">
                        <p class="d-block">Featured</p><br>
                        <input <?php 
                        if($f_fatured_old == 'Yes'){
                            echo "Checked";
                        }
                        ?> class="form-check-input" type="radio" name="featured_food-update" id="foodFeaturedYes" value="Yes">
                        <label class="form-check-label" for="foodFeaturedYes">Yes</label>

                        <input <?php 
                        if($f_fatured_old == 'No'){
                            echo "Checked";
                        }
                        ?> class="form-check-input" type="radio" name="featured_food-update" id="foodFeaturedNo" value="No">
                        <label class="form-check-label" for="foodFeaturedNo">No</label>
                    </div>
                    <br>
                    <div class="form-check form-check-inline">
                        <p class="d-block">Active statuse</p><br>
                        <input <?php 
                        if($f_active_old == 'Yes'){
                            echo "Checked";
                        }
                        ?>  class="form-check-input" type="radio" name="active_food-update" id="foodactiveYes" value="Yes">
                        <label class="form-check-label" for="foodactiveYes">Yes</label>
    
                        <input <?php 
                        if($f_active_old == 'No'){
                            echo "Checked";
                        }
                        ?> class="form-check-input" type="radio" name="active_food-update" id="foodactiveNo" value="No">
                        <label class="form-check-label" for="foodactiveNo">No</label>
                    </div>
                    
                    <div class="form-group">
                        <label for="foodImage">Current Image</label><br>
                        <img width="150px" src="<?= "../media-file/food/". $f_img_name_old; ?>" alt="">
                    </div>
                    <div class="form-group">
                        <label for="foodImage">Food Image</label>
                        <input type="file" class="form-control-file" id="foodImage"  name="food-image-update">
                    </div>
                    <div class="form-group">
                        <label for="foodDesc">Food Description</label>
                        <textarea class="form-control" id="foodDesc" rows="3"  name="food-description-update"><?= $f_desc_old; ?></textarea>
                    </div>

                    <button type="add-food" name="update-food" class="btn btn-primary">Submit</button>

                </form>
                
            </div>
    </div>
    <div class="clearfix"></div>
</div>
<!-- main area end -->
<?php

if(isset($_POST['update-food'])){
    // gather all the updated info
    $f_name_new = $_POST['food-name-update'];
    $f_price_new = $_POST['food-price-update'];
    $f_category_new = $_POST['food-category-update'];
    $f_desc_new = $_POST['food-description-update'];
    $f_featured_new = $_POST['featured_food-update'];
    $f_active_new = $_POST['active_food-update'];
    

	if(isset($_FILES['food-image-update']['name']) && isset($_FILES['food-image-update']['name']) != '' ){
         // upload new image to the media
         $f_img_new = $_FILES['food-image-update']['name'];
         $exp_img_name_new = explode('.', $f_img_new );
         $get_img_ext = end($exp_img_name_new);

         // rename the image
         $f_img_new = "food-image" . rand(000,9999) . '.' . $get_img_ext;

         // upload image path
         $path_new_img = "../media-file/food/" . $f_img_new;
         // temp path 
         $tmp_new_img = $_FILES['food-image-update']['tmp_name'];

         $upload_new_img = move_uploaded_file($tmp_new_img, $path_new_img);
         
         //check whether image upload successs or not
         if($upload_new_img == true){
                // remove the old image
                $path_old_img = "../media-file/food/" . $f_img_name_old;
                $remove_old_img = unlink($path_old_img);
                if($remove_old_img == true){
                // insert the value to database
                $sql_update_food_img = "UPDATE tbl_food SET f_image_name = '$f_img_new' WHERE f_id = '$id'";
                $query_sql_update_food_img = mysqli_query($conn, $sql_update_food_img);

                if($query_sql_update_food_img == false){
                    $_SESSION['image_name_update_error'] = "Image name updated faild";
                    echo '<script>window.location.href = " ' . SITEURL . '/admin/manage-food.php' . ' ";</script>';
                }
        
                }
            }


    }

     // insert the value to database
 $sql_update_food = "UPDATE tbl_food SET
 f_name = '$f_name_new',
 f_description = '$f_desc_new',
 f_price = '$f_price_new',
 category_id = '$f_category_new',
 f_featured = '$f_featured_new',
 f_active = '$f_active_new'
  WHERE f_id = '$id'";

 $query_sql_update_food = mysqli_query($conn, $sql_update_food);
 if($query_sql_update_food == true){
     $_SESSION['food_upate_success'] = "Success to update the food";
     echo '<script>window.location.href = " ' . SITEURL . '/admin/manage-food.php' . ' ";</script>';
 }
 else{
     $_SESSION['food_upate_error'] = "Error to update the food";
     echo '<script>window.location.href = " ' . SITEURL . '/admin/manage-food.php' . ' ";</script>';
 }

}// submit end

?>
<?php include('partials/footer.php') ?>