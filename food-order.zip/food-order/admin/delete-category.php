<?php include('../config/constants.php'); ?>
<?php 

//check whether id and image is true or false

if(isset($_GET['imageName']) && isset($_GET['id'])){
	$id = $_GET['id'];
	$cat_img = $_GET['imageName'];

	// remove the physical image file if available

	if($cat_img != ""){

		//image path
		$path = '../media-file/category/'.$cat_img;
		$remove = unlink($path);

		// check if the image is removed
		if($remove == false){
			// set session
			$_SESSION['cat_Faild_to_remove'] = "Faild to remove category Image";

			header('LOCATION:' .SITEURL. 'admin/manage-category.php');
			die();
		}
	}
	// delete category from database
	$sql  = "DELETE FROM noman_test WHERE id=$id";
	$res = mysqli_query($conn, $sql);
	
	// IF cat delete success
	if($res == true){
		$_SESSION['cat_delete_success'] = 'Category Deleted successfully';

		// redirect to manage category
		header('LOCATION:' .SITEURL. 'admin/manage-category.php');
	}
	else{
		$_SESSION['cat_delete_error'] = 'category faild to delte :(';
	}
	//redirect to the manage page
}
else
{
	// redirect to manage cetagory
	header('LOCATION:'. SITEURL . 'admin/manage-category.php');
}
?>